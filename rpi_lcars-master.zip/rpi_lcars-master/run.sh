#!/bin/sh
cd app
xinit /usr/bin/python lcars.py
