import logging

logger = logging.getLogger('wia')
logging.basicConfig(level=logging.INFO)
