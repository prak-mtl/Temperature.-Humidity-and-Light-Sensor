#!/bin/sh
sudo apt-get update
sudo apt-get install python-pygame python-pil

# on dietpi/raspbian lite install xinit
sudo apt-get install xinit

