import wia
import unittest2
import time
import os

class CustomerTest(unittest2.TestCase):
    pass
    # def test_signup(self):
    #     response = wia.Customer.signup(fullName='Erlich Blachman',
    #                                     email='erlich@blachmanity.com',
    #                                     password='password')
    #     print(response)
    #
    # def test_login(self):
    #     response = wia.Customer.login(username='erlich@blachmanity.com',
    #                                     password='password')
    #     print(response)
    
if __name__ == '__main__':
    unittest2.main()
