Official Wia SDK for Python
===================================

A Python library for Wia's API.


Setup
-----

You can install this package by using the pip tool and installing:

    $ pip install wia


Setting up a Wia Account
---------------------------

Sign up for Wia at https://www.wia.io/signup.


Using the Wia API
--------------------

Documentation can be found here:

- https://docs.wia.io
